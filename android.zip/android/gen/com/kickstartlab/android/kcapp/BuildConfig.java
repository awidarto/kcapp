/** Automatically generated file. DO NOT MODIFY */
package com.kickstartlab.android.kcapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}